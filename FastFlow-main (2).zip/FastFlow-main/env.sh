module load u18/cuda/10.2
module load u18/cudnn/7.6.5-cuda-10.2
source ~/fastflow/bin/activate

export PATH=$PATH:~/misc/bin

